#!/usr/bin/env python3
import json
import time
import os
import re

LOG_PATH = "/var/log/miner/custom/pearl_compute_engine.log"
STATS_PATH = "/var/run/hive/miner.json"

def get_amd_metrics():
    # Fallback default values
    temp = 60
    fan = 50
    power = 120
    
    # Query Linux sysfs directly for ultra-fast, zero-overhead AMD hardware stats
    try:
        if os.path.exists("/sys/class/drm/card0/device/hwmon/hwmon0/temp1_input"):
            with open("/sys/class/drm/card0/device/hwmon/hwmon0/temp1_input", "r") as f:
                temp = int(f.read().strip()) // 1000
        if os.path.exists("/sys/class/drm/card0/device/hwmon/hwmon0/pwm1"):
            with open("/sys/class/drm/card0/device/hwmon/hwmon0/pwm1", "r") as f:
                fan = int(int(f.read().strip()) / 255 * 100)
    except:
        pass
    return temp, fan, power

def parse_logs():
    last_rate = 0.0
    if os.path.exists(LOG_PATH):
        try:
            with open(LOG_PATH, "r") as f:
                lines = f.readlines()
                # Scan backwards to capture the newest 10-second SRBMiner-style log row
                for line in reversed(lines):
                    match = re.search(r"GPU0:\s+([\d.]+)\s+H/s", line)
                    if match:
                        last_rate = float(match.group(1))
                        break
        except:
            pass
    return last_rate

def main():
    while True:
        time.sleep(10)
        rate = parse_logs()
        temp, fan, power = get_amd_metrics()
        
        # Build the exact strict JSON payload structure expected by the HiveOS dashboard API
        stats = {
            "hs": [rate],               # Array of hashrates per GPU
            "hs_units": "hs",           # Metric unit token
            "temp": [temp],             # Core temperatures array
            "fan": [fan],               # Fan speeds percentage array
            "power": [power],           # Power draws array
            "ar": [0, 0],               # [Accepted Shares, Rejected Shares]
            "bus_numbers": [0]          # PCIe Bus Index tracking
        }
        
        try:
            with open(STATS_PATH, "w") as f:
                json.dump(stats, f)
        except Exception as e:
            pass

if __name__ == "__main__":
    main()