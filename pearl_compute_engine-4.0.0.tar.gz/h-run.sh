#!/usr/bin/env bash

# Navigate strictly into our custom deployment folder path
cd "$(dirname "$0")"

. /hive/custom/pearl_compute_engine/h-manifest.conf
. /hive-config/wallet.conf

# Automatically resolve HiveOS Flight Sheet template variables
POOL_HOST=$(echo $CUSTOM_URL | cut -d ":" -f 1)
POOL_PORT=$(echo $CUSTOM_URL | cut -d ":" -f 2)
WALLET_ADDR=$CUSTOM_TEMPLATE
WORKER_NAME=$RIG_NAME

# Output the runtime parameter configuration text file cleanly on boot
echo "$POOL_HOST" > config.txt
echo "$POOL_PORT" >> config.txt
echo "$WALLET_ADDR" >> config.txt
echo "$WORKER_NAME" >> config.txt

# Ensure directories exist for the logger engine
mkdir -p /var/log/miner/custom
touch /var/log/miner/custom/pearl_compute_engine.log

echo "[HiveOS Custom Wrapper] Launching API Telemetry Loop..."
python3 stats_api.py &

echo "[HiveOS Custom Wrapper] Unleashing Vulkan Unthrottled 14-TFLOPS Compute Engine..."
# Execute and continuously feed the output to the tracking log file
./pearl_compute_engine 2>&1 | tee /var/log/miner/custom/pearl_compute_engine.log